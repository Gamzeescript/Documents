package com.ampersand.pri.imp;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.ampersand.pri.model.Ast;
import com.ampersand.pri.util.AFacade;
import com.ampersand.pri.util.DAO;

@Transactional
public class AsistenciaRep extends AFacade<Ast> implements DAO<Ast>{
	
	@Autowired
	private SessionFactory sessionFactory;
	
	
	public AsistenciaRep() {
		super(Ast.class);
	}
	
	@Override
	public SessionFactory sessionFactory() {
		return sessionFactory;
	}

}
