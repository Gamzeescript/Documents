package com.ampersand.pri.control;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.ampersand.pri.imp.AlumnoRep;
import com.ampersand.pri.imp.AsistenciaRep;
import com.ampersand.pri.imp.EstadoRep;
import com.ampersand.pri.model.Al;
import com.ampersand.pri.model.Ast;
import com.ampersand.pri.model.Est;

@Controller
public class TomaAsistencia {
	
	@Autowired
	@Qualifier("astRep")
	private AsistenciaRep astRep;
	
	@Autowired
	@Qualifier("alRep")
	private AlumnoRep alRep;
	
	
	@Autowired
	@Qualifier("estRep")
	private EstadoRep estRep;
	
	private ModelAndView mv = new ModelAndView();
	
	
	@RequestMapping(value = "/vistaAsistencias", method = RequestMethod.GET)
	public ModelAndView asignacionAsistencia() {
		mv.addObject("lista", alRep.read());
		mv.addObject("listaestado", estRep.read());
		mv.setViewName("AsistenciaAlumno");
		return mv;
		
	}
	
	
	
	/* guardar por ahi por ahi */
	
	@RequestMapping(value = "/guardaAsistencia",  method = RequestMethod.POST)
	public ModelAndView checkeado(@RequestParam("aaIdolAl") String aaIdolAl, @RequestParam("aaFechaAst") String aaFechaAst, @RequestParam("aaIdolEst") String aaIdolEst) {
		ModelAndView mv = new ModelAndView("AsistenciaAlumno");
		
		Ast asistencia = new Ast();
		Al alumno = new Al();
		Est estado = new Est();
		estado.setAaIdolEst(Integer.parseInt(aaIdolEst));
		alumno.setAaIdolAl(Integer.parseInt(aaIdolAl));
		asistencia.setAl(alumno);
		asistencia.setAaFechaAst(aaFechaAst);
		asistencia.setEst(estado);
		astRep.create(asistencia);
		
		System.out.println(asistencia.getAl());
		System.out.println(asistencia.getAaFechaAst());
		System.out.println(asistencia.getEst());
		
		mv.addObject("lista", alRep.read());
		return mv;
		
	}

}
