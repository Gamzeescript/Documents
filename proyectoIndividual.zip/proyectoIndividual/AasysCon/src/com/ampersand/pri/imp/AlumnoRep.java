package com.ampersand.pri.imp;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.ampersand.pri.model.Al;
import com.ampersand.pri.util.AFacade;
import com.ampersand.pri.util.DAO;

@Transactional
public class AlumnoRep extends AFacade<Al> implements DAO<Al>{

	 @Autowired
	    private SessionFactory sessionFactory;

	    public AlumnoRep() {
	        super(Al.class);
	    }

	    @Override
	    public SessionFactory sessionFactory() {
	        return sessionFactory;
	    }
	    
	
}
