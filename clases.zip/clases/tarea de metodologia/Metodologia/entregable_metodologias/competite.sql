drop database if exists competite;
create database competite;
use competite;

create table participante(
participante_id int not null primary key auto_increment,
nombre varchar(20) not null,
apellido varchar(20) not null,
movil varchar(10) not null,
email varchar(70) not null,
carnet varchar(5) not null
) Engine InnoDB;

create table competencias(
competencia_id int not null primary key auto_increment,
nombre varchar(30) not null,
descripcion varchar(150) not null
)Engine InnoDB;

-- agregar una tabla intermedia de competencias y participantes
create table asignacion(
asignacion_id int not null primary key auto_increment,
participante_id int not null,
competencia_id int not null,
constraint fk_participante foreign key (participante_id) references participante(participante_id) ON DELETE CASCADE ON UPDATE CASCADE,
constraint fk_competencia foreign key (competencia_id) references competencia(competencia_id) ON DELETE CASCADE ON UPDATE CASCADE
)Engine InnoDB;