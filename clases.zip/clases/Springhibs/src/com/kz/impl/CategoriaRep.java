package com.kz.impl;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.kz.models.Categoria;
import com.kz.utils.AbsFacade;
import com.kz.utils.Dao;

@Repository
@Transactional
public class CategoriaRep extends AbsFacade<Categoria> implements Dao<Categoria> {

	@Autowired
	private SessionFactory sessionFactory;

	public CategoriaRep() {
		super(Categoria.class);
	}

	@Override
	public SessionFactory sessionFactory() {
		return sessionFactory;
	}

	public int getCantCategs() {
		return this.read().size();
	}

}
