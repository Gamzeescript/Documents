package com.kz.imp;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.kz.models.Categoria;
import com.kz.utils.AbsFacade;
import com.kz.utils.Dao;

@Repository
public class CategoriaRep extends AbsFacade<Categoria> implements Dao<Categoria> {

	@Autowired
	SessionFactory sessionFactory;
	
	public CategoriaRep() {
		super(Categoria.class);
	}

	@Override
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	/*Metodos especificos*/
	public List<Categoria> getCuenta(){
		return null;
	}
}
