package com.kz.imp;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.kz.models.Cliente;
import com.kz.utils.AbsFacade;
import com.kz.utils.Dao;

public class ClienteRep extends AbsFacade<Cliente> implements Dao<Cliente> {

	@Autowired
	private SessionFactory getSF;
	
	public ClienteRep() {
		super(Cliente.class);
	}

	@Override
	public SessionFactory getSessionFactory() {
		return getSF;
	}

	/*Metodos especificos*/
}