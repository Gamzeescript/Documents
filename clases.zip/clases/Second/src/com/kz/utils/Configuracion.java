package com.kz.utils;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import com.kz.imp.CategoriaRep;

@Configuration
@EnableWebMvc
@ComponentScan(basePackages = {"com.kz"})
public class Configuracion {

	@Bean
	InternalResourceViewResolver vistas() {
		InternalResourceViewResolver resultado = new InternalResourceViewResolver();
		resultado.setPrefix("/");
		resultado.setSuffix(".jsp");
		return resultado;
	}
	
	@Bean
	public SessionFactory obtener() {
		return Hib.getSessionFactory();
	}
	
	@Bean
	public CategoriaRep catRep() {
		return new CategoriaRep();
	}
	
}
