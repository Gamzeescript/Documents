package com.l.segundatarea.util;

public class Configuracion {

}
