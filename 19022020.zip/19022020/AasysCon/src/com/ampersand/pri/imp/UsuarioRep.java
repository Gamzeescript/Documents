package com.ampersand.pri.imp;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.ampersand.pri.model.Usr;
import com.ampersand.pri.util.AFacade;
import com.ampersand.pri.util.DAO;

public class UsuarioRep extends AFacade<Usr> implements DAO<Usr>{
	
	@Autowired
	private SessionFactory sessionFactory;

	public UsuarioRep() {
		super(Usr.class);
		
	}
	
	@Override
	public SessionFactory sessionFactory() {
		return sessionFactory;
	}
	
	
	
	
	
	

}
