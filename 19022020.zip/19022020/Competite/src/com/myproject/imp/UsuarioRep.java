package com.myproject.imp;

import java.util.List;

import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;

import com.myproject.model.Usuario;
import com.myproject.util.AFacade;
import com.myproject.util.DAO;

public class UsuarioRep extends AFacade<Usuario> implements DAO<Usuario>{
	
	CriteriaBuilder cb;
	CriteriaQuery<Usuario> cq;
	Query q; 
	
	@Autowired
	private SessionFactory sessionFactory;

	public UsuarioRep() {
		super(Usuario.class);
		
	}
	
	@Override
	public SessionFactory sessionFactory() {
		return sessionFactory;
	}
	
	/* Comento esta wea porque al final Spring es una vaina fea */
	/* Metodo de inicio de sesion */
	@SuppressWarnings("unchecked")
	public Usuario inicioSesion(Usuario usuario, String clave) {
		Transaction t = session.beginTransaction();
		try {
			 cb = session.getCriteriaBuilder();
			 cq = cb.createQuery(Usuario.class);
			 Root<Usuario> root = cq.from(Usuario.class);
			 
			 String query= "select * from usuario where usuario = ? and clave = aes_encrypt(,'123')";
			 q = session.createNativeQuery(query);
			 q.setParameter(1, usuario.getUsuario());
			 q.setParameter(2, clave);
			 List<Usuario> listaUsuario = q.getResultList();
			 if (!listaUsuario.isEmpty()) {
	                usuario = listaUsuario.get(0);
	            }
		}catch (Exception e) {
			session.flush();
			return null;
		} finally {
			session.flush();
		}
		session.flush();
		t.commit();
		return usuario;
	}
	
	
	

}
