package com.myproject.control;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.myproject.imp.UsuarioRep;
import com.myproject.model.Usuario;

@Controller
public class InicioSesion {
	
	
	@Autowired
	@Qualifier("userRep")
	private UsuarioRep userRep;
	
	private Usuario logged = new Usuario();
	
	private ModelAndView mv = new ModelAndView();
    
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public ModelAndView login() {
		mv.setViewName("login");
		return mv;
	}
	
	/* metodo para el login*/
	

	

}
