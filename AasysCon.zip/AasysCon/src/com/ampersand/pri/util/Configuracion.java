package com.ampersand.pri.util;

import java.util.Properties;

import javax.sql.DataSource;

import org.apache.tomcat.dbcp.dbcp2.BasicDataSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import com.ampersand.pri.imp.AlumnoRep;

@Configuration
@EnableWebMvc
@EnableTransactionManagement(proxyTargetClass = true)
@ComponentScan(basePackages = {"com.ampersand"})
public class Configuracion {
	
	
	@Bean
	public AlumnoRep alRep() {
		return new AlumnoRep();
	}
	
	@Bean
	public InternalResourceViewResolver views() {
		InternalResourceViewResolver vr = new InternalResourceViewResolver();
		vr.setPrefix("/");
		vr.setSuffix(".jsp");
		return vr;
	}
	
	@Bean
	public DataSource dataSource() {
		BasicDataSource ds = new BasicDataSource();
		ds.setDriverClassName("com.mysql.jdbc.Driver");
		ds.setUrl("jdbc:mysql://usam-sql.sv.cds:3306/aaSys?useSSL=false");
		ds.setUsername("kz");
		ds.setPassword("kzroot");		
		return ds;
		
	}
	
	private Properties getHibernateProperties() {
		Properties hibernateProperties = new Properties();
		hibernateProperties.setProperty("hibernate.dialect", "org.hibernate.dialect.MySQLDialect");
		return hibernateProperties;
		
	}
	
	@Bean
	public LocalSessionFactoryBean sessionFactory() {
		LocalSessionFactoryBean f = new LocalSessionFactoryBean();
		f.setDataSource(dataSource());
		f.setHibernateProperties(getHibernateProperties());
		f.setPackagesToScan("com.ampersand.pri.model");
		return f;
	}
	
	@Bean
	public PlatformTransactionManager transactionManger() {
		HibernateTransactionManager hib = new HibernateTransactionManager();
		hib.setSessionFactory(sessionFactory().getObject());
		return hib;
	}
	
	
	

}
