package com.ampersand.pri.util;

public class ConfiguracionSeguridad {

}
