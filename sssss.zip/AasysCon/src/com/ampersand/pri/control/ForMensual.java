package com.ampersand.pri.control;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.ampersand.pri.imp.MesRep;

@Controller
public class ForMensual {

	@Autowired
	@Qualifier("msRep")
	private MesRep msRep;
	
	private ModelAndView mv = new ModelAndView();
	
	/* metodo para recorrer meses*/
	
	@RequestMapping(value = "/recorrerMes", method = RequestMethod.GET)
	public ModelAndView esteMes() {
		mv.addObject("mes", msRep.read());	
		System.out.println("calendario calendario de amoooor, calendario de amor, juntos todo el anio tu y yo");
		mv.setViewName("AsistenciaAlumno");
		return mv;
	}
	
}
