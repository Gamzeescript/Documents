package com.ampersand.pri.imp;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.ampersand.pri.model.Ms;
import com.ampersand.pri.util.AFacade;
import com.ampersand.pri.util.DAO;

@Transactional
public class MesRep extends AFacade<Ms> implements DAO<Ms>{
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public MesRep() {
		super(Ms.class);
	}
	
	public SessionFactory sessionFactory() {
		return sessionFactory;
	}
	
	

}